## 1.1 Генерация файлов

1. [Сайт - Free tast generation](https://beeceptor.com/resources/test-data-generator/)
- Простой и быстрый сайт на английсом языке, позволеят перевести на русский, можно скачать тестовые файлы разного размера и расширения.
- Поддерживает форматы: .txt, .pdf, .jpg, .mp4, .docx, .xlsx, .zip, .mp3 и другие
- Размеры: от 100 КБ до 5 ГБ
- Есть возможность задать пользовательский размер


2. [Сайт - Example File Generator - Create Files in Any Size & Format Я](https://www.convertiom.com/file-generator.html) 
- Простой и быстрый сайт на английсом языке, позволеят перевести на русский, можно скачать тестовые файлы разного размера и расширения.
- Поддерживает форматы: .txt, .pdf, .jpg, .mp4, .docx, .xlsx, .zip, .mp3 и другие
- Размеры: от 100 КБ до 5 ГБ
- Есть возможность задать пользовательский размер


## 1.2 Генерации тестовых данных

1. [Сайт - Random Data Tools](https://randomdatatools.ru/)

- Русскоязычный генератор валидных, но случайных пользовательских данных.

2. [Сайт - Free tast generation](https://beeceptor.com/resources/test-data-generator/)
- Простой и быстрый сайт на английсом языке, позволеят перевести на русский, можно скачать тестовые файлы разного размера и расширения.
- Поддерживает форматы: .txt, .pdf, .jpg, .mp4, .docx, .xlsx, .zip, .mp3 и другие
- Размеры: от 100 КБ до 5 ГБ
- Есть возможность задать пользовательский размер

[
  {
    "fullName": "Christopher Goldner",
    "phoneNumber": "(829) 926-4550",
    "email": "Shyanne.Schulist@hotmail.com",
    "address": "8040 Quarry Road",
    "country": "Australia",
    "countryCode": "AX",
    "city": "South Kelvin",
    "zipCode": "83954-7295",
    "latitude": "79.5186",
    "longitude": "76.4307"
  },
  {
    "fullName": "Rose Daugherty",
    "phoneNumber": "(807) 319-7227",
    "email": "Dameon.Bashirian@hotmail.com",
    "address": "8953 Derrick Field",
    "country": "Australia",
    "countryCode": "GU",
    "city": "Wehnerburgh",
    "zipCode": "37644",
    "latitude": "53.1792",
    "longitude": "118.8949"
  },
  {
    "fullName": "Roman Bernier",
    "phoneNumber": "895-994-4105",
    "email": "Sonny57@yahoo.com",
    "address": "788 E Water Street",
    "country": "Australia",
    "countryCode": "MC",
    "city": "West Dario",
    "zipCode": "23019",
    "latitude": "23.2467",
    "longitude": "-5.7657"
  },
  {
    "fullName": "Bridget Zieme",
    "phoneNumber": "277.249.8695 x4846",
    "email": "Cornelius66@hotmail.com",
    "address": "612 Wuckert Fort",
    "country": "Australia",
    "countryCode": "BH",
    "city": "Dickensburgh",
    "zipCode": "47279-0077",
    "latitude": "-3.363",
    "longitude": "69.6195"
  },
  {
    "fullName": "Beulah Kessler",
    "phoneNumber": "263-288-5981 x3431",
    "email": "Selena99@yahoo.com",
    "address": "4495 Victoria Road",
    "country": "Australia",
    "countryCode": "AD",
    "city": "Amiyastad",
    "zipCode": "51448-4305",
    "latitude": "28.5598",
    "longitude": "-153.7666"
  }
]