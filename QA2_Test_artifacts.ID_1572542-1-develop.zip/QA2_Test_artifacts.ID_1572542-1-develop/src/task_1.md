Id тест 1.1 кейс на позитивную проверку
За головок - Авторизация с правильными данными
Предусловие 
     - Есть доступ на сайт https://www.saucedemo.com/
     - Пользователь standard_user существует
шаги:
    Открыть браузер и перейти на страницу https://www.saucedemo.com/
    ввести в поле Username: standard_user
    ввести в поле Password: secret_sauce
    нажать на кнопку Login
Ожидаемый результат - пользователь успешно авторизовался и перешел на страницу сайта  https://www.saucedemo.com/inventory.html
Постусловие
     - Пользователь остаётся авторизованным (если не требуется выход)
     - При необходимости — выйти из аккаунта     

ID тест 2.1 на негативные проверки
Заголовок - Авторизация с неправильными данными
Предусловие
     - Есть доступ на сайт https://www.saucedemo.com/
     - Пользователь (konor/1) не существует
шаги:
     - Перейти на страницу https://www.saucedemo.com/
     - ввести в поле Username: konor
     - ввести в поле Password: 1
     - нажать на кнопку Login
Ожидаемый результат - пользователь не авторизован. Появляется сообщение об ошибке с текстом: Epic sadface: Username and password do not match any user in this service
Пост условие
     - Пользователь остаётся авторизованным (если не требуется выход)
     - При необходимости — выйти из аккаунта

ID Тест 2.2
Заголовок - Авторизация с неправильныйм логином 1 буква
Предусловие
     - Есть доступ на сайт https://www.saucedemo.com/
     - Пользователь standard_usr/secret_sauce
шаги:
     - Перейти на страницу https://www.saucedemo.com/
     - ввести в поле Usarname: standard_usr
     - ввести в поле Password: secret_sauce
     - нажать на кнопку: Login
Ожидаемый результат - логин не прошёл. Появляется сообщение об ошибке: Epic sadface: Username and password do not match any user in this service
Пост условие

ID Тест 2.3
Заголовок - Авторизация с неправильным паролем
Предусловие 
     - Есть доступ на сайт https://www.saucedemo.com/
     - Пользователь standard_usеr/sauce
шаги:
     - перейти на страницу https://www.saucedemo.com/
     - ввести в поле Usarname: standard_usеr
     - ввести в поле Password: sause
     - нажать кнопку Login 
Ожидаемый результат - пароль не прошёл. Появляется сообщение об ошибке: Epic sadface: Username and password do not match any user in this service

ID Тест 2.4 
Заголовок - Авторизация с пустой строкой Username
Предусловие 
     - Есть доступ на сайт https://www.saucedemo.com/
     - Пользователь авторизован
шаги:
     - Перейти на страцину https://www.saucedemo.com/
     - ввести в Usarname: 
     - ввести в Passwjrd:secret_sauce
     - нажать кнопку: Login
Ожидаемый результат - перейти на сайт не вышло. Появляется сообщение об ошибке: Epic sadface: Username is required


ID Тест 2.5
Заголовок - Авторизация с пустой строкой Password
Предусловие 
     - Есть доступ на сайт https://www.saucedemo.com/
     - Пользователь авторизован
шаги:
     - Перейти на страцину https://www.saucedemo.com/
     - ввести в Usarname: standard_usеr
     - ввести в Passwjrd:
     - нажать кнопку: Login
Ожидаемый результат - перейти на сайт не вышло. Появляется сообщение об ошибке: Epic sadface: Password is required
